import { showHome } from './home.js';

document.querySelector('a').addEventListener('click', showHome);
showHome();